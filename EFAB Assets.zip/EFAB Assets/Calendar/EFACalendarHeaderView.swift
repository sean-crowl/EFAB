//
//  EFACalendarHeaderView.swift
//  EFAB
//
//  Created by Brett Keck on 5/20/16.
//  Copyright © 2016 Eleven Fifty Academy. All rights reserved.
//

import UIKit

class EFACalendarHeaderView: UIView {
    @IBOutlet weak var monthLabel: UILabel!
}
